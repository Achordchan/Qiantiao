//
//  __Tests.swift
//  钱条Tests
//
//  Created by A chord on 2024/12/6.
//

import Testing
@testable import __

struct __Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
